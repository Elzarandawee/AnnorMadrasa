

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.android.synthetic.main.activity_admin.*

class AdminActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin)

        auth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()

        btn_remove_content.setOnClickListener {
            val contentId = et_content_id.text.toString()
            removeContent(contentId)
        }

        btn_add_ad.setOnClickListener {
            val adLink = et_ad_link.text.toString()
            addAdvertisement(adLink)
        }
    }

    private fun removeContent(contentId: String) {
        firestore.collection("contents").document(contentId).delete()
            .addOnSuccessListener {
                // Content removed successfully
            }
            .addOnFailureListener {
                // Handle failure
            }
    }

    private fun addAdvertisement(adLink: String) {
        firestore.collection("advertisements").add(mapOf("link" to adLink))
            .addOnSuccessListener {
                // Advertisement added successfully
            }
            .addOnFailureListener {
                // Handle failure
            }
    }
}
