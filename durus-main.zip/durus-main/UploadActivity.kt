import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.storage.FirebaseStorage
import kotlinx.android.synthetic.main.activity_upload.*

class UploadActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var storage: FirebaseStorage
    private val PICK_IMAGE_REQUEST = 71
    private var fileUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_upload)

        auth = FirebaseAuth.getInstance()
        storage = FirebaseStorage.getInstance()

        btn_choose.setOnClickListener {
            val intent = Intent()
            intent.type = "image/*"
            intent.action = Intent.ACTION_GET_CONTENT
            startActivityForResult(Intent.createChooser(intent, "Select Image"), PICK_IMAGE_REQUEST)
        }

        btn_upload.setOnClickListener {
            uploadFile()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null && data.data != null) {
            fileUri = data.data
            img_preview.setImageURI(fileUri)
        }
    }

    private fun uploadFile() {
        if (fileUri != null) {
            val fileReference = storage.reference.child("uploads/${auth.currentUser?.uid}/${fileUri?.lastPathSegment}")
            fileReference.putFile(fileUri!!)
                .addOnSuccessListener {
                    // File uploaded successfully
                }
                .addOnFailureListener {
                    // Handle unsuccessful uploads
                }
        } else {
            // No file selected
        }
    }
}
