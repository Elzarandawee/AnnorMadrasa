
import com.itextpdf.text.Document
import com.itextpdf.text.DocumentException
import com.itextpdf.text.Paragraph
import com.itextpdf.text.pdf.PdfWriter
import java.io.FileOutputStream

object CertificateGenerator {

    fun generateCertificate(userName: String, folderName: String, outputPath: String) {
        val document = Document()
        PdfWriter.getInstance(document, FileOutputStream(outputPath))
        document.open()
        document.add(Paragraph("Certificate of Completion"))
        document.add(Paragraph("This is to certify that $userName has completed the folder: $folderName"))
        document.add(Paragraph("Date: ${java.util.Date()}"))
        document.add(Paragraph("Signature: Elzarandawee"))

        document.close()
    }
}
