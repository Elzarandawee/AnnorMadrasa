
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.pedro.library.AutoPermission
import com.pedro.library.livevideo.LiveView
import kotlinx.android.synthetic.main.activity_live.*

class LiveActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_live)

        val liveView = findViewById<LiveView>(R.id.liveView)
        liveView.setPermissionAutoAccept { true }

        btn_start_live.setOnClickListener {
            val title = et_title.text.toString()
            liveView.startBroadcast(title)
        }

        btn_stop_live.setOnClickListener {
            liveView.stopBroadcast()
        }

        btn_edit_live.setOnClickListener {
            liveView.editBroadcast()
        }
    }
}
